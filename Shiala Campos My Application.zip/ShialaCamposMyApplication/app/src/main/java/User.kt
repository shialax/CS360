package com.example.shialacamposmyapplication

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class User {
    @PrimaryKey
    var uid = 0

    @ColumnInfo(name = "username")
    var userName: String? = null

    @ColumnInfo(name = "password")
    var password: String? = null
}