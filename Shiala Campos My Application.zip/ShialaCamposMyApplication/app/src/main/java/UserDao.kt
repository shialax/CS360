package com.example.shialacamposmyapplication

import android.app.DownloadManager
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert


@Dao
interface UserDao {
    @get:DownloadManager.Query("SELECT * FROM user")
    val all: List<User?>?

    @DownloadManager.Query("SELECT * FROM user WHERE uid IN (:userIds)")
    fun loadAllByIds(userIds: IntArray?): List<User?>?

    @DownloadManager.Query(
        "SELECT * FROM user WHERE username LIKE :first AND " +
                "password LIKE :last LIMIT 1"
    )
    fun findByName(first: String?, last: String?): User?

    @Insert
    fun insertAll(vararg users: User?)

    @Delete
    fun delete(user: User?)
}
