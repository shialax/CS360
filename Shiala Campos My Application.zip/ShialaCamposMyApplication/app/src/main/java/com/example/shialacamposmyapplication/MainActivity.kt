package com.example.shialacamposmyapplication
import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.room.*


class MainActivity : AppCompatActivity() {
    var db: AppDatabase? = null
    protected fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        db = Room.databaseBuilder(
            getApplicationContext(),
            AppDatabase::class.java, "users"
        ).build()
    }

    fun RegisterClick(v: View?) {
        val usernameText = findViewById(R.id.editTextUsername) as EditText
        val passwordText = findViewById(R.id.editTextTextPassword) as EditText
        val nameTextValue = usernameText.text.toString()
        val passwordTextValue = passwordText.text.toString()
        if (!checkLogin(nameTextValue, passwordTextValue)) {
            createUser(nameTextValue, passwordTextValue)
        }
    }

    fun LoginClick(v: View?) {
        val usernameText = findViewById(R.id.editTextUsername) as EditText
        val passwordText = findViewById(R.id.editTextTextPassword) as EditText
        val nameTextValue = usernameText.text.toString()
        val passwordTextValue = passwordText.text.toString()
        if (checkLogin(nameTextValue, passwordTextValue)) {
            setContentView(R.layout.main_display)
        }
    }

    private fun checkLogin(username: String, password: String): Boolean {
        val userDao: UserDao = db.userDao()
        val user: User = userDao.findByName(username, password)
        return user != null
    }

    private fun createUser(username: String, password: String) {
        val userDao: UserDao = db.userDao()
        val user = User()
        user.userName = username
        user.password = password
        userDao.insertAll(user)
    }
}



